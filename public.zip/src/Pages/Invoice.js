import React from 'react'

function Invoice() {
  return (
    <div>
      <h1>Invoice</h1>
    </div>
  )
}

export default Invoice
