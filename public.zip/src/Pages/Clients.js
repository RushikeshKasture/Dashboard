import * as React from "react";
import Redirect from "../Components/Redirect/redirect";


function Clients() {
  return (
    <div>
      <Redirect />
    </div>
  );
}

export default Clients;
