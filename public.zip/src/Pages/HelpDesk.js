import React from 'react'

function HelpDesk() {
  return (
    <div>
      <h1>HelpDesk</h1>
    </div>
  )
}

export default HelpDesk
